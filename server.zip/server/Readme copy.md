## SET UP

## MVC ARCHITECTURE
## DATABASE CONNECTION - local &

## create users - vendor, buyer, admin
- bu
